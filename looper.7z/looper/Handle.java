/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1.looper;

import static java.lang.System.out;
import java.util.*;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Handle {

  protected Looper looper;
  protected LinkedList<String> $msgList = new LinkedList<String>();

  public void setLooper(Looper looper) {
    this.looper = looper;

    while ($msgList.size() != 0) {

      out.printf("size = %s\n", $msgList.size());

      String str = $msgList.removeFirst();
      looper.addMsg(str);
    }
  }

  public void postMsg(String str) {
    if (looper == null) {
      $msgList.addLast(str);
    } else {
      looper.addMsg(str);
    }
  }

  public void handleMsg(String str) {
    out.printf("handle.msg......%s\n", str);
  }
}
