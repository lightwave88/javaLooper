/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1.looper;

import static java.lang.System.out;
import static java.lang.Thread.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Test_1 extends Thread {

  public Looper looper;
  public Handle handle;

  public Test_1() {
    // 必須在建構式中設定
    handle = new Handle();
  }

  public void run() {
    out.printf("thread(%s) start\n", Thread.currentThread().getId());

    Looper looper = new Looper(handle);

    // 阻塞
    looper.start();

    out.println("thread stop");
  }
}
