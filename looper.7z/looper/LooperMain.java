/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1.looper;

import static java.lang.System.out;
import static java.lang.Thread.*;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class LooperMain {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {

    Thread th = Thread.currentThread();
    out.printf("thread(%s)\n", th.getId());

    Test_1 t1 = new Test_1();

    // 開始執行序
    t1.start();

    // 線程間的通訊
    t1.handle.postMsg("test");

    try {
      // TODO code application logic here

      sleep(6000);
    } catch (InterruptedException ex) {
      out.println(ex.toString());
    }
    out.println("looper.quite()");

    // 手動結束這個線程
    t1.handle.looper.quite();
  }

}
