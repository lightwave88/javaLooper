/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1.looper;

import java.util.*;
import static java.lang.System.out;
import static java.lang.Thread.*;

/**
 *
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Looper {

  protected Handle handle;
  protected LinkedList<String> $msgList = new LinkedList<String>();
  protected boolean $stop = false;

  public Looper(Handle handle) {
    this.handle = handle;
    this.handle.setLooper(this);
  }

  public void start() {

    out.println("looper start");
    // 阻塞線程用
    while ($stop != true) {

      // 檢查訊息列表
      _checkMsgList();

      try {
        // 弄出空檔，讓 $stop 有時間獲得更新值
        // 不然會無窮迴圈下去
        sleep(1);
      } catch (InterruptedException ex) {
      }
    }
    out.println("looper end");
  }

  public void quite() {
    $stop = true;
  }

  public void addMsg(String str) {
    $msgList.addLast(str);
  }

  // 檢查訊息列表
  protected void _checkMsgList() {

    while ($msgList.size() != 0) {

      out.printf("_checkMsgList size = %s\n", $msgList.size());

      String str = $msgList.removeFirst();

      // 通知 handle
      handle.handleMsg(str);
    }
  }
}
